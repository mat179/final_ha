--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.0
-- Dumped by pg_dump version 10.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.rx DROP CONSTRAINT fk_rx_user_id;
ALTER TABLE ONLY public.rx DROP CONSTRAINT fk_rx_doctor_id;
ALTER TABLE ONLY public.doctor DROP CONSTRAINT fk_doctor_user_id;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_pkey;
ALTER TABLE ONLY public.rx DROP CONSTRAINT pk_rx_id;
ALTER TABLE ONLY public.doctor DROP CONSTRAINT pk_doctor_id;
ALTER TABLE ONLY public.oauth_client_token DROP CONSTRAINT oauth_client_token_pkey;
ALTER TABLE ONLY public.oauth_client_details DROP CONSTRAINT oauth_client_details_pkey;
ALTER TABLE ONLY public.oauth_access_token DROP CONSTRAINT oauth_access_token_pkey;
ALTER TABLE public."user" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.rx ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.doctor ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.user_id_seq;
DROP TABLE public."user";
DROP SEQUENCE public.rx_id_seq;
DROP TABLE public.rx;
DROP TABLE public.oauth_refresh_token;
DROP TABLE public.oauth_code;
DROP TABLE public.oauth_client_token;
DROP TABLE public.oauth_client_details;
DROP TABLE public.oauth_approvals;
DROP TABLE public.oauth_access_token;
DROP SEQUENCE public.doctor_id_seq;
DROP TABLE public.doctor;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: doctor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctor (
    id integer NOT NULL,
    speciality_code character varying(20) NOT NULL,
    create_time date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_updated date NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.doctor OWNER TO postgres;

--
-- Name: doctor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.doctor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.doctor_id_seq OWNER TO postgres;

--
-- Name: doctor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.doctor_id_seq OWNED BY public.doctor.id;


--
-- Name: oauth_access_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_access_token (
    token_id character varying(255) DEFAULT NULL::character varying,
    token bytea,
    authentication_id character varying(255) NOT NULL,
    user_name character varying(255) DEFAULT NULL::character varying,
    client_id character varying(255) DEFAULT NULL::character varying,
    authentication bytea,
    refresh_token character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.oauth_access_token OWNER TO postgres;

--
-- Name: oauth_approvals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_approvals (
    userid character varying(255) DEFAULT NULL::character varying,
    clientid character varying(255) DEFAULT NULL::character varying,
    scope character varying(255) DEFAULT NULL::character varying,
    status character varying(10) DEFAULT NULL::character varying,
    expiresat timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    lastmodifiedat timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.oauth_approvals OWNER TO postgres;

--
-- Name: oauth_client_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_client_details (
    client_id character varying(255) NOT NULL,
    resource_ids character varying(255) DEFAULT NULL::character varying,
    client_secret character varying(255) DEFAULT NULL::character varying,
    scope character varying(255) DEFAULT NULL::character varying,
    authorized_grant_types character varying(255) DEFAULT NULL::character varying,
    web_server_redirect_uri character varying(255) DEFAULT NULL::character varying,
    authorities character varying(255) DEFAULT NULL::character varying,
    access_token_validity numeric,
    refresh_token_validity numeric,
    additional_information character varying(4096) DEFAULT NULL::character varying,
    autoapprove character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.oauth_client_details OWNER TO postgres;

--
-- Name: oauth_client_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_client_token (
    token_id character varying(255) DEFAULT NULL::character varying,
    token bytea,
    authentication_id character varying(255) NOT NULL,
    user_name character varying(255) DEFAULT NULL::character varying,
    client_id character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.oauth_client_token OWNER TO postgres;

--
-- Name: oauth_code; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_code (
    code character varying(255) DEFAULT NULL::character varying,
    authentication bytea
);


ALTER TABLE public.oauth_code OWNER TO postgres;

--
-- Name: oauth_refresh_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oauth_refresh_token (
    token_id character varying(255) DEFAULT NULL::character varying,
    token bytea,
    authentication bytea
);


ALTER TABLE public.oauth_refresh_token OWNER TO postgres;

--
-- Name: rx; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rx (
    id integer NOT NULL,
    user_id integer NOT NULL,
    doctor_id integer NOT NULL,
    symptoms character varying(250),
    medicine character varying(250),
    create_time date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_updated date NOT NULL
);


ALTER TABLE public.rx OWNER TO postgres;

--
-- Name: rx_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rx_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rx_id_seq OWNER TO postgres;

--
-- Name: rx_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rx_id_seq OWNED BY public.rx.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    email character varying(50) NOT NULL,
    password character varying(250) NOT NULL,
    first_name character varying(20) NOT NULL,
    last_name character varying(20),
    age numeric,
    gender numeric,
    role numeric
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: doctor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor ALTER COLUMN id SET DEFAULT nextval('public.doctor_id_seq'::regclass);


--
-- Name: rx id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rx ALTER COLUMN id SET DEFAULT nextval('public.rx_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: doctor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctor (id, speciality_code, create_time, last_updated, user_id) FROM stdin;
\.
COPY public.doctor (id, speciality_code, create_time, last_updated, user_id) FROM '$$PATH$$/2878.dat';

--
-- Data for Name: oauth_access_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_access_token (token_id, token, authentication_id, user_name, client_id, authentication, refresh_token) FROM stdin;
\.
COPY public.oauth_access_token (token_id, token, authentication_id, user_name, client_id, authentication, refresh_token) FROM '$$PATH$$/2880.dat';

--
-- Data for Name: oauth_approvals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_approvals (userid, clientid, scope, status, expiresat, lastmodifiedat) FROM stdin;
\.
COPY public.oauth_approvals (userid, clientid, scope, status, expiresat, lastmodifiedat) FROM '$$PATH$$/2881.dat';

--
-- Data for Name: oauth_client_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_client_details (client_id, resource_ids, client_secret, scope, authorized_grant_types, web_server_redirect_uri, authorities, access_token_validity, refresh_token_validity, additional_information, autoapprove) FROM stdin;
\.
COPY public.oauth_client_details (client_id, resource_ids, client_secret, scope, authorized_grant_types, web_server_redirect_uri, authorities, access_token_validity, refresh_token_validity, additional_information, autoapprove) FROM '$$PATH$$/2882.dat';

--
-- Data for Name: oauth_client_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_client_token (token_id, token, authentication_id, user_name, client_id) FROM stdin;
\.
COPY public.oauth_client_token (token_id, token, authentication_id, user_name, client_id) FROM '$$PATH$$/2883.dat';

--
-- Data for Name: oauth_code; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_code (code, authentication) FROM stdin;
\.
COPY public.oauth_code (code, authentication) FROM '$$PATH$$/2884.dat';

--
-- Data for Name: oauth_refresh_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oauth_refresh_token (token_id, token, authentication) FROM stdin;
\.
COPY public.oauth_refresh_token (token_id, token, authentication) FROM '$$PATH$$/2885.dat';

--
-- Data for Name: rx; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rx (id, user_id, doctor_id, symptoms, medicine, create_time, last_updated) FROM stdin;
\.
COPY public.rx (id, user_id, doctor_id, symptoms, medicine, create_time, last_updated) FROM '$$PATH$$/2886.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id, email, password, first_name, last_name, age, gender, role) FROM stdin;
\.
COPY public."user" (id, email, password, first_name, last_name, age, gender, role) FROM '$$PATH$$/2888.dat';

--
-- Name: doctor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.doctor_id_seq', 5, true);


--
-- Name: rx_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rx_id_seq', 23, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_seq', 12, true);


--
-- Name: oauth_access_token oauth_access_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_access_token
    ADD CONSTRAINT oauth_access_token_pkey PRIMARY KEY (authentication_id);


--
-- Name: oauth_client_details oauth_client_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_client_details
    ADD CONSTRAINT oauth_client_details_pkey PRIMARY KEY (client_id);


--
-- Name: oauth_client_token oauth_client_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oauth_client_token
    ADD CONSTRAINT oauth_client_token_pkey PRIMARY KEY (authentication_id);


--
-- Name: doctor pk_doctor_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor
    ADD CONSTRAINT pk_doctor_id PRIMARY KEY (id);


--
-- Name: rx pk_rx_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rx
    ADD CONSTRAINT pk_rx_id PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: doctor fk_doctor_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor
    ADD CONSTRAINT fk_doctor_user_id FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: rx fk_rx_doctor_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rx
    ADD CONSTRAINT fk_rx_doctor_id FOREIGN KEY (doctor_id) REFERENCES public.doctor(id);


--
-- Name: rx fk_rx_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rx
    ADD CONSTRAINT fk_rx_user_id FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- PostgreSQL database dump complete
--

